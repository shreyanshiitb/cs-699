Contributions:
	TEAM NAME: Codigos
	TEAM MEMBERS:
		Kartavya Kothari - 193050021
		Aditya Jain - 193050028
		Shreyansh Jain - 193050040


Presentation:
Overleaf presentation link: https://www.overleaf.com/read/nmmjswqrwjxt

Document:
- We have also implemented a sample.bib file but have used in doc bibtex
Overleaf Document link: https://www.overleaf.com/3133771175zjsryhnzxsrs

References:
https://tex.stackexchange.com/questions/67310/shadow-blocks-in-beamer?rq=1
https://overleaf.com